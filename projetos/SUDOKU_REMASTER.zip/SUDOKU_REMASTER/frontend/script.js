const board = document.getElementById("sudoku-board");

let tabuleiro = []; // tabuleiro atual

function criarGrid(tabuleiroData) {
  board.innerHTML = '';
  tabuleiro = tabuleiroData;

  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      const input = document.createElement("input");
      input.maxLength = 1;
      input.classList.add("cell");

      if (tabuleiro[i][j] !== 0) {
        input.value = tabuleiro[i][j];
        input.disabled = true;
        input.classList.add("fixed");
      } else {
        input.addEventListener("input", () => {
          const valor = parseInt(input.value);
          tabuleiro[i][j] = isNaN(valor) ? 0 : valor;
        });
      }

      board.appendChild(input);
    }
  }
}

function gerarJogo(dificuldade = "facil") {
  fetch(`/gerar?dificuldade=${dificuldade}`)
    .then(res => res.json())
    .then(data => criarGrid(data.tabuleiro))
    .catch(err => console.error("Erro ao gerar jogo:", err));
}

function validarTabuleiro() {
  // envia tabuleiro inteiro para validação
  fetch("/validar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tabuleiro })
  })
    .then(res => res.json())
    .then(data => {
      alert(data.valido ? "✅ Tabuleiro válido!" : "❌ Há erros no tabuleiro.");
    });
}

function resolverTabuleiro() {
  fetch("/resolver", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tabuleiro })
  })
    .then(res => res.json())
    .then(data => criarGrid(data.solucao));
}

function salvar() {
  fetch("/salvar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tabuleiro })
  }).then(() => alert("💾 Jogo salvo!"));
}

function carregar() {
  fetch("/carregar")
    .then(res => res.json())
    .then(data => criarGrid(data.tabuleiro));
}

// Gera um jogo inicial ao carregar a página
gerarJogo();
